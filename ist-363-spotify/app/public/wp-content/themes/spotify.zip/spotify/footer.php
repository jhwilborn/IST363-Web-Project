    </main>
    <footer>
        Copyright information here
    </footer>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/lastfm.api.md5.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/lastfm.api.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/lastfm.api.cache.js"></script>

    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/custom-lastfm.js"></script>

    <?php wp_footer(); ?>
    </body>

    </html>