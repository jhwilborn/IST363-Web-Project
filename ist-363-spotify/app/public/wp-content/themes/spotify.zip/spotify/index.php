<?php 
get_header();
include 'partials/player.php';
include 'partials/showcase.php';
include 'partials/new-releases.php';
include 'partials/most-popular.php';
include 'partials/top-songs-by-genre.php';
include 'partials/top-songs-by-location.php';

// include 'partials/review-css-grid.php';
// include 'partials/grid-demo.php';
// include 'partials/artists.php';
// include 'partials/posts.php' ;
get_footer();
?>
<!-- shft+alt+a block comment -->