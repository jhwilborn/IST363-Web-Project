<?php
require get_template_directory() . '/includes/add-theme-support.php'; //requires Creates dependency, do not move code forward w/out
require get_template_directory() . '/includes/register-post-types.php';
?>