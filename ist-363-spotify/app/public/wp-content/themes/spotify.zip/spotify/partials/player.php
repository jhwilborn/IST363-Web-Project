<section class="player" id="player">
    <div class="container">
        <audio controls>
            <source src="<?php bloginfo('template_directory') ?>/audio/horse.mp3" type="audio/mp3">
            Your browser does not support the audio tag.
        </audio>
    </div>
</section>