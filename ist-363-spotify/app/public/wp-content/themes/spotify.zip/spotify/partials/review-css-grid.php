<section>
    <div class="container">
        <h2>Review CSS Grid</h2>
        <div class="grid2">
            <!-- .album.album${Album$}*60 apply default and secondary class (auto numeration with $), with content in the div-->
            <div class="album album1">
                <img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art">
        </div>
            <div class="album album2">Album2</div>
            <div style="background-image:url('<?php bloginfo('template_directory');?>/images/bhoco.jpg')" class="album album3">Album3</div>
            <div class="album album4">Album4</div>
            <div class="album album5">Album5</div>
            <div class="album album6"><img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art"></div>
            <div class="album album7">Album7</div>
            <div class="album album8">Album8</div>
            <div class="album album9">Album9</div>
            <div class="album album10">Album10</div>
            <div class="album album11">Album11</div>
            <div class="album album12">Album12</div>
            <div class="album album13"><img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art"></div>
            <div class="album album14"><img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art"></div>
            <div class="album album15">Album15</div>
            <div class="album album16">Album16</div>
            <div class="album album17">Album17</div>
            <div class="album album18">Album18</div>
            <div class="album album19">Album19</div>
            <div class="album album20">Album20</div>
            <div class="album album21">Album21</div>
            <div class="album album22">Album22</div>
            <div class="album album23">Album23</div>
            <div class="album album24">Album24</div>
            <div class="album album25">Album25</div>
            <div class="album album26">Album26</div>
            <div class="album album27">Album27</div>
            <div class="album album28">Album28</div>
            <div class="album album29">Album29</div>
            <div class="album album30">Album30</div>
            <div class="album album31">Album31</div>
            <div class="album album32">Album32</div>
            <div class="album album33">Album33</div>
            <div class="album album34">Album34</div>
            <div class="album album35">Album35</div>
            <div class="album album36">Album36</div>
            <div class="album album37">Album37</div>
            <div class="album album38">Album38</div>
            <div class="album album39">Album39</div>
            <div class="album album40">Album40</div>
            <div class="album album41"><img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art"></div>
            <div class="album album42">Album42</div>
            <div class="album album43">Album43</div>
            <div class="album album44">Album44</div>
            <div class="album album45">Album45</div>
            <div class="album album46">Album46</div>
            <div class="album album47">Album47</div>
            <div class="album album48">Album48</div>
            <div class="album album49">Album49</div>
            <div class="album album50">Album50</div>
            <div class="album album51">Album51</div>
            <div class="album album52">Album52</div>
            <div class="album album53">Album53</div>
            <div class="album album54">Album54</div>
            <div class="album album55">Album55</div>
            <div class="album album56">Album56</div>
            <div class="album album57"><img class="responsive-img" src="<?php bloginfo('template_directory');?>/images/bhoco.jpg" alt="beyonce homecoming album art"></div>
            <div class="album album58">Album58</div>
            <div class="album album59">Album59</div>
            <div class="album album60">Album60</div>
        </div>
    </div> <!--container-->
</section>