<section class="section white">
    <div class="container">
        <h2>New Releases</h2>
        <ul class="row" id="songList">
        </ul>
    </div> <!-- container -->
</section>