<section class="section grey">
    <div class="container">
        <h2>Top songs by genre</h2>
        <ul id="tagList" class="tag-list"></ul>
        <ol id="trackList" class="track-list"></ol>
    </div> <!-- container -->
</section>