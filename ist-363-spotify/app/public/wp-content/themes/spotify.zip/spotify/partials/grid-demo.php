<section>
    <div class="container">
        <h2>CSS Grid</h2>
         <div class="grid"> <!--.item{$}*9 -->
            <div class="item">1</div>
            <div class="item">2</div>
            <div class="item">3</div>
            <div class="item">4</div>
            <div class="item">5</div>
            <div class="item">6</div>
            <div class="item">7</div>
            <div class="item">8</div>
            <div class="item">9</div>
        </div>
    </div>
</section>