<section class="section primary">
    <div class="container">
        <h2>Most popular</h2>
    </div> <!-- container -->
</section>