<section class="section white">
    <div class="container">
        <h2>Showcase</h2>
    </div> <!-- container -->
</section>