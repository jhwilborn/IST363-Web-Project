<section class="section black">
    <div class="container">
        <h2>Top songs by location</h2>
    </div> <!-- container -->
</section>